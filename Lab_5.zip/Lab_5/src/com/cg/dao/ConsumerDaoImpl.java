package com.cg.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.dto.BillDetails;
import com.cg.dto.Consumers;
import com.cg.exception.BillException;
import com.cg.util.DBUtil;


public class ConsumerDaoImpl implements ConsumerDao{

	Connection conn = null;
	Statement st = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	
	@Override
	public String getDetails(Consumers consumer) throws BillException {
		String name = null;
		
		try
		{
		conn = DBUtil.getCon();
		System.out.println("Got Connection: ");
		String qry ="SELECT * FROM Consumers WHERE consumer_num=?";
		pst=conn.prepareStatement(qry);
		pst.setLong(1, consumer.getConsumerNo());
		rs=pst.executeQuery();
		rs.next();
		name = rs.getString("consumer_name");
		
		}
		catch(Exception e)
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return name;
}

	public long billId() throws BillException
	{
		String qry = "SELECT seq_bill_num.NEXTVAL FROM DUAL";
		long billNum;
		try
		{
			conn = DBUtil.getCon();
			st = conn.createStatement();
			rs = st.executeQuery(qry);
			rs.next();
			billNum = rs.getLong(1);
		} 
		catch (Exception e)
		{
			throw new BillException(e.getMessage());
		}
		finally
		{
			try 
			{
				rs.close();
				st.close();
				conn.close();  //ALL JDBC APIs throws SQLException
			} 
			catch (SQLException e) 
			{
				throw new BillException(e.getMessage());
			}
		}
		return billNum;
	}
	
	
	@Override
	public int setBillDetails(BillDetails billDet, Consumers consumer) throws BillException {
		
		String insertQry = "INSERT INTO BillDetails(bill_num,consumer_num,cur_reading,unitConsumed,netAmount,bill_date) VALUES(?, ?, ?, ?, ?, sysdate)";
		int dataAdded;
		
		try
		{
			conn=DBUtil.getCon();
			pst=conn.prepareStatement(insertQry);
			pst.setLong(1, billId());
			pst.setLong(2, consumer.getConsumerNo());
			pst.setDouble(3, billDet.getCurrReading());
			pst.setDouble(4, billDet.getUnitConsumed());
			pst.setDouble(5, billDet.getNetAmount());
		
			dataAdded =pst.executeUpdate();
			System.out.println("data: "+dataAdded);
		} 
		catch (Exception e) 
		{
			throw new BillException(e.getMessage());
		} 
		finally
		{
			try 
			{
				pst.close();
				conn.close();
			} 
			catch (SQLException e) 
			{
				
				throw new BillException(e.getMessage());
			}
		}
		return dataAdded;
	
	}
}