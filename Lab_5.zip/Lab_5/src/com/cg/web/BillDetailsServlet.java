package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Consumers;
import com.cg.exception.BillException;
import com.cg.service.ConsumerService;
import com.cg.service.ConsumerServiceImpl;

@WebServlet("/BillDetailsServlet")
public class BillDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
    public BillDetailsServlet() {
        super();
       
    }

	public void init(ServletConfig config) throws ServletException {
		
	}

	public void destroy() {
		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		HttpSession session = request.getSession(true);
		RequestDispatcher rd;
		
		Consumers consumer = new Consumers();
		ConsumerService conSer = new ConsumerServiceImpl();
		
		String conNo = request.getParameter("txtNumber");
		String lastMonRead = request.getParameter("txtLast");
		String currMonRead = request.getParameter("txtCurrent");
		
		long consumerNo = Long.parseLong(conNo);
		consumer.setConsumerNo(consumerNo);
		
		session.setAttribute("ObjNo", conNo);
		session.setAttribute("ObjLast", lastMonRead);
		session.setAttribute("ObjCurr", currMonRead);
		
		try 
		{
			String name = conSer.getDetails(consumer);
			session.setAttribute("ObjName", name);
		} 
		catch (BillException e) 
		{
			e.printStackTrace();
		}
		
		rd=request.getRequestDispatcher("SuccessPage");
		rd.forward(request, response);
	
	}

}
