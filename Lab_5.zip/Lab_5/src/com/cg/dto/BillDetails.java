package com.cg.dto;

public class BillDetails {
	
	private Consumers consumer;
	private long billNo;
	//private long consumerNo = consumer.getConsumerNo();
	private double currReading;
	private double unitConsumed;
	private double netAmount;


public long getBillNo() {
	return billNo;
}
public void setBillNo(long billNo) {
	this.billNo = billNo;
}
public double getCurrReading() {
	return currReading;
}
public void setCurrReading(double currReading) {
	this.currReading = currReading;
}
public double getUnitConsumed() {
	return unitConsumed;
}
public void setUnitConsumed(double unitConsumed) {
	this.unitConsumed = unitConsumed;
}
public double getNetAmount() {
	return netAmount;
}
public void setNetAmount(double netAmount) {
	this.netAmount = netAmount;
}

public BillDetails() {
	super();
	// TODO Auto-generated constructor stub
}
 
public BillDetails(long billNo, long consumerNo, double currReading,
		double unitConsumed, double netAmount) {
	super();
	this.billNo = billNo;
	
	this.currReading = currReading;
	this.unitConsumed = unitConsumed;
	this.netAmount = netAmount;
}
 
}
